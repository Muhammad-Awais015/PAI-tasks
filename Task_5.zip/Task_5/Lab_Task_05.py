import cv2
import numpy as np
import matplotlib.pyplot as plt

IMG_PATH = "C:\Users\anssa\Downloads\Task_5\Screenshot 2026-03-07 225657.png"

raw = cv2.imread(IMG_PATH)

if raw is None:
    print("Failed to load image — check the path.")
    quit()


def render(frame, heading, is_gray=False):
    plt.figure(figsize=(6, 6))
    if is_gray:
        plt.imshow(frame, cmap="gray")
    else:
        plt.imshow(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    plt.title(heading)
    plt.axis("off")
    plt.show()


render(raw, "Original Image")

grey = cv2.cvtColor(raw, cv2.COLOR_BGR2GRAY)
render(grey, "Grayscale", is_gray=True)

smoothed = cv2.GaussianBlur(grey, (7, 7), 0)
render(smoothed, "Smoothed (Gaussian Blur)", is_gray=True)

edge_map = cv2.Canny(smoothed, 80, 150)
render(edge_map, "Canny Edges", is_gray=True)

_, thresh = cv2.threshold(grey, 120, 255, cv2.THRESH_BINARY)
render(thresh, "Threshold (Binary)", is_gray=True)

resized = cv2.resize(raw, (200, 200))
render(resized, "Resized 200×200")

h, w = raw.shape[:2]
r1, r2 = int(h * 0.2), int(h * 0.7)
c1, c2 = int(w * 0.2), int(w * 0.7)
cropped = raw[r1:r2, c1:c2]
render(cropped, "Cropped Region")

canvas = raw.copy()
cv2.line(canvas, (30, 30), (300, 30), (0, 255, 0), 2)
cv2.rectangle(canvas, (40, 40), (250, 250), (255, 0, 0), 3)
cv2.circle(canvas, (200, 200), 80, (0, 0, 255), 3)
render(canvas, "Shapes Drawn")

annotated = raw.copy()
cv2.putText(annotated, "Computer Vision", (50, 60),
            cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)
render(annotated, "Text Overlay")

flipped = cv2.flip(raw, 1)
render(flipped, "Horizontally Flipped")

img_h, img_w = raw.shape[:2]
centre_pt = (img_w // 2, img_h // 2)
rot_matrix = cv2.getRotationMatrix2D(centre_pt, 45, 1.0)
rotated = cv2.warpAffine(raw, rot_matrix, (img_w, img_h))
render(rotated, "Rotated 45°")

cv2.imwrite("edges_output.jpg", edge_map)
