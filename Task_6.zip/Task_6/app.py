from flask import Flask, render_template, request, jsonify
import cv2
import numpy as np
import base64
import re
import urllib.request
import os

app = Flask(__name__)

CASCADE_PATH = "haarcascade_russian_plate_number.xml"
if not os.path.exists(CASCADE_PATH):
    url = ("https://raw.githubusercontent.com/opencv/opencv/master/"
           "data/haarcascades/haarcascade_russian_plate_number.xml")
    urllib.request.urlretrieve(url, CASCADE_PATH)

plate_cascade = cv2.CascadeClassifier(CASCADE_PATH)


def decode_image(file_storage):
    data = np.frombuffer(file_storage.read(), np.uint8)
    return cv2.imdecode(data, cv2.IMREAD_COLOR)

def encode_image(img):
    _, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 92])
    return base64.b64encode(buf).decode("utf-8")

def preprocess_plate(roi):
    gray  = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    gray  = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    blur  = cv2.GaussianBlur(gray, (3, 3), 0)
    _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return th

def extract_text_opencv(plate_img):
    try:
        import pytesseract
        text = pytesseract.image_to_string(
            plate_img,
            config="--psm 8 --oem 3 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        )
        cleaned = re.sub(r"[^A-Z0-9\-]", "", text.upper()).strip()
        return cleaned if cleaned else "UNREADABLE"
    except Exception:
        return "OCR_UNAVAILABLE"

def draw_plate_box(img, x, y, w, h, text, idx):
    cv2.rectangle(img, (x-3, y-3), (x+w+3, y+h+3), (0, 200, 255), 1)
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 230, 120), 2)

    label    = f"PLATE {idx}: {text}"
    (tw, th) = cv2.getTextSize(label, cv2.FONT_HERSHEY_DUPLEX, 0.55, 1)[0]
    lx, ly   = x, y - 8
    if ly < th + 4:
        ly = y + h + th + 4

    cv2.rectangle(img, (lx, ly - th - 4), (lx + tw + 8, ly + 2), (0, 230, 120), -1)
    cv2.putText(img, label, (lx + 4, ly - 2),
                cv2.FONT_HERSHEY_DUPLEX, 0.55, (0, 0, 0), 1)

    length = 12
    color  = (0, 230, 120)
    thick  = 2
    for (cx, cy, sx, sy) in [(x,y,1,1),(x+w,y,-1,1),(x,y+h,1,-1),(x+w,y+h,-1,-1)]:
        cv2.line(img, (cx, cy), (cx + sx*length, cy), color, thick)
        cv2.line(img, (cx, cy), (cx, cy + sy*length), color, thick)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/detect", methods=["POST"])
def detect():
    file = request.files.get("image")
    if not file:
        return jsonify({"error": "No image provided"}), 400

    img = decode_image(file)
    if img is None:
        return jsonify({"error": "Could not read image"}), 400

    h, w = img.shape[:2]
    if max(h, w) > 1920:
        scale = 1920 / max(h, w)
        img   = cv2.resize(img, (int(w*scale), int(h*scale)))

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.equalizeHist(gray)

    plates = plate_cascade.detectMultiScale(
        gray,
        scaleFactor = 1.05,
        minNeighbors= 4,
        minSize     = (60, 20),
        maxSize     = (400, 150)
    )

    results   = []
    annotated = img.copy()

    if len(plates) == 0:
        plates = find_plates_contour(img)

    for i, (x, y, pw, ph) in enumerate(plates, start=1):
        roi       = img[y:y+ph, x:x+pw]
        processed = preprocess_plate(roi)
        text      = extract_text_opencv(processed)

        draw_plate_box(annotated, x, y, pw, ph, text, i)

        _, rbuf   = cv2.imencode(".jpg", roi)
        plate_b64 = base64.b64encode(rbuf).decode()

        results.append({
            "id":        i,
            "text":      text,
            "x": int(x), "y": int(y),
            "w": int(pw), "h": int(ph),
            "plate_img": plate_b64
        })

    cv2.putText(annotated, f"Plates found: {len(results)}", (10, 32),
                cv2.FONT_HERSHEY_DUPLEX, 0.9, (0, 230, 120), 2)

    return jsonify({
        "image":   encode_image(annotated),
        "count":   len(results),
        "plates":  results,
        "message": f"Detected {len(results)} plate(s)"
    })


def find_plates_contour(img):
    gray    = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges   = cv2.Canny(blurred, 30, 120)
    kernel  = cv2.getStructuringElement(cv2.MORPH_RECT, (17, 3))
    closed  = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, kernel)

    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    candidates = []
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        ar   = w / float(h)
        area = w * h
        if 1.5 < ar < 6.0 and 1000 < area < 80000:
            candidates.append((x, y, w, h))

    return candidates[:5]


if __name__ == "__main__":
    app.run(debug=True, port=5000)
