from flask import Flask, request, jsonify, render_template
from openai import OpenAI
from gtts import gTTS
from PyPDF2 import PdfReader
import spacy
import os
import uuid

app = Flask(__name__)

client = OpenAI(
    api_key="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",
    base_url="https://api.groq.com/openai/v1",
)

MODEL = "llama-3.3-70b-versatile"

nlp = spacy.load("en_core_web_sm")

syllabus_text = ""

os.makedirs("static", exist_ok=True)

@app.route("/")
def home():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    global syllabus_text

    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]

    
    if file.filename.endswith(".txt"):
        syllabus_text = file.read().decode("utf-8")

    elif file.filename.endswith(".pdf"):
        reader = PdfReader(file)

        text = ""

        for page in reader.pages:
            extracted = page.extract_text()

            if extracted:
                text += extracted

        syllabus_text = text

    else:
        return jsonify({"error": "Only PDF or TXT files allowed"}), 400

    return jsonify({
        "message": "Syllabus uploaded successfully"
    })

@app.route("/ask", methods=["POST"])
def ask():
    global syllabus_text

    try:
        data = request.get_json()

        user_question = data.get("question", "")

        if not user_question:
            return jsonify({
                "error": "Question is required"
            }), 400

        doc = nlp(user_question)

        tokens = [token.text for token in doc]

        nouns = [token.text for token in doc if token.pos_ == "NOUN"]

        keywords = [token.text for token in doc if not token.is_stop]

        print("Tokens:", tokens)
        print("Nouns:", nouns)
        print("Keywords:", keywords)

        prompt = f"""
You are a friendly Urdu-speaking tutor.

Answer ONLY from this syllabus:

{syllabus_text}

If the question is outside the syllabus, say:
"Yeh topic aap ke course ka hissa nahi hai"

User Question:
{user_question}
"""

        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "Tum ek madad gar Urdu tutor ho. Sirf syllabus se jawab do."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=1024,
            temperature=0.7,
        )

        answer = response.choices[0].message.content

        audio_file = f"static/answer_{uuid.uuid4().hex[:8]}.mp3"

        tts = gTTS(answer, lang="ur")

        tts.save(audio_file)

        return jsonify({
            "question": user_question,
            "tokens": tokens,
            "keywords": keywords,
            "answer": answer,
            "audio": "/" + audio_file
        })

    except Exception as e:
        return jsonify({
            "error": str(e)
        }), 500

@app.route("/voice", methods=["POST"])
def voice():
    global syllabus_text

    try:

        if "audio" not in request.files:
            return jsonify({
                "error": "No audio file received"
            }), 400

        audio_file = request.files["audio"]

        temp_filename = f"static/voice_{uuid.uuid4().hex[:8]}.webm"

        audio_file.save(temp_filename)

        with open(temp_filename, "rb") as f:

            transcription = client.audio.transcriptions.create(
                model="whisper-large-v3",
                file=f,
                response_format="text"
            )

        question = (
            transcription.strip()
            if isinstance(transcription, str)
            else transcription.text.strip()
        )

        if not question:
            return jsonify({
                "error": "Voice not understood"
            }), 422

        doc = nlp(question)

        tokens = [token.text for token in doc]

        nouns = [token.text for token in doc if token.pos_ == "NOUN"]

        keywords = [token.text for token in doc if not token.is_stop]

        print("Voice Tokens:", tokens)
        print("Voice Nouns:", nouns)

        prompt = f"""
You are a friendly Urdu-speaking tutor.

Answer ONLY from this syllabus:

{syllabus_text}

If the question is outside the syllabus, say:
"Yeh topic aap ke course ka hissa nahi hai"

Question:
{question}
"""

        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "Tum ek madad gar Urdu tutor ho."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            max_tokens=1024,
            temperature=0.7,
        )

        answer = response.choices[0].message.content

        output_audio = f"static/reply_{uuid.uuid4().hex[:8]}.mp3"

        tts = gTTS(answer, lang="ur")

        tts.save(output_audio)

        return jsonify({
            "transcribed_text": question,
            "tokens": tokens,
            "keywords": keywords,
            "answer": answer,
            "audio": "/" + output_audio
        })

    except Exception as e:

        return jsonify({
            "error": str(e)
        }), 500

    finally:

        if "temp_filename" in locals() and os.path.exists(temp_filename):
            os.remove(temp_filename)


if __name__ == "__main__":
    app.run(debug=True)