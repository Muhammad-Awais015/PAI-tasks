from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():

    reply = ""

    if request.method == "POST":

        user_message = request.form["message"].lower()

        if "admission" in user_message:
            reply = "Admissions are open now."

        elif "fee" in user_message:
            reply = "The fee is 50,000 per semester."

        elif "deadline" in user_message:
            reply = "Last date for admission is 30 June."

        elif "program" in user_message:
            reply = "We offer BSCS, BBA, and BS AI."

        else:
            reply = "Sorry, I do not understand."

    return render_template("index.html", reply=reply)

if __name__ == "__main__":
    app.run(debug=True)